var Blippar = require('blippar');
var blipp   = Blippar.blipp;

// ======================================================
// =                        BLIPP                       =
// ======================================================
blipp.setTitle('Globe');
blipp.getPeel()
     .setOrientation('portrait')
     .setType("fit")
     .setOffset([0, -30])
     .setScale(60);

// ======================================================
// =                        SCENE                       =
// ======================================================     
blipp.read("main.json");
var scene = blipp.getScene();
var sW    = blipp.getScreenWidth()  * 1.003;
var sH    = blipp.getScreenHeight() * 1.003;

scene.onCreate = function()
{
	// Define the screen space
	var screen = scene.getScreen();
	
	// Get scene models
	scene.stars  = scene.getChild("Stars");
	scene.base   = scene.getChild("Base");
	scene.shadow = scene.base.getChild("Shadow");
	scene.night  = scene.base.getChild("Night");
	scene.center = scene.base.getChild("Center");
	scene.map 	 = scene.center.getChild("Map");
	scene.pinLon = scene.map.getChild("PointLon");
	scene.pinLat = scene.pinLon.getChild("PointLat");

	// Attach background to screen and adjust its size
	scene.stars.setParent(screen).setScale(sH);

	// Global scene variables 
	scene.icons 		 = [];
	scene.iconsLocations = ["52.5200° N, 13.4049° E",	//	Berlin
							"51.5073° N, 00.1277° W",	//	London
							"34.0522° N, 118.2436° W",	//	Los Angeles
						  	"19.0759° N, 72.8776° E",	//	Mumbai
						  	"40.7127° N, 74.0059° W",	//	New York
						  	"48.8566° N, 02.3522° E",	//	Paris
						  	"23.5505° S, 46.6333° W",	//	Sao Paulo
						  	"35.6884° N, 139.6917° E"	//	Tokyo
						   ];
	scene.iconsTextures  = ["Berlin.png",
							"London.png",
						  	"LosAngeles.png",
						  	"Mumbai.png",
						  	"New-York.png",
						  	"Paris.png",
						  	"SaoPaulo.png",
						  	"Tokyo.png"
						   ];
	scene.currentIconIndex = 0;
						 
	// Build the icons
	buildIcons(screen);
}

scene.onShow = function() {	
	// Animate the globe
	scene.center.animate().rotateZ(-360).duration(24000).loop();	
	scene.pinLat.animate().scale(1.05).duration(500).delay(1000).onEnd = function () { pinBounce(); }

	// Pin the current location
	pinLocation(scene.currentIconIndex);

	console.log("Globe");	
}

scene.onTrack = function () { 
	// Fade out the star backgrounf
	scene.base.animate().rotateX(0).duration(500);
	scene.stars.animate().alpha(0).duration(500);
}

scene.onTrackLost = function () { 
	// Fade in the star background
	scene.base.animate().rotateX(75).duration(500);
	scene.stars.animate().alpha(1).duration(500);
}

// ======================================================
// =                        USER FUNCTIONS              =
// ======================================================	
function buildIcons(screen) {

	// var iconPosX = (sH - 3 * sW / 4) / 2;
	// var iconPosY = sH / 8;
	var iconsCount = 5;
	var iconPosX   = (2/3) * (sH/2);
	var iconPosY   = sW / (iconsCount - 1);
	var sprite;

	// Create the far left icon
	sprite  = screen.addSprite()
							 .setTextures(scene.iconsTextures)
							 .setActiveTexture(0)
						     .setTranslation(iconPosX, -1.7 * iconPosY, 0)
						     .setRotation(0, 0, -90)
						     .setScale(sW/10)
						     .setType('aura')
						     .setClickable(false);
	scene.icons.push(sprite);

	// Create the left icon
	sprite  = screen.addSprite()
							 .setTextures(scene.iconsTextures)
							 .setActiveTexture(1)
						     .setTranslation(iconPosX, -iconPosY, 0)
						     .setRotation(0, 0, -90)
						     .setScale(sW/6)
						     .setType('aura')
						     .setClickable(false);
	scene.icons.push(sprite);

	// Create the middle icon
	sprite = screen.addSprite()
							 .setTextures(scene.iconsTextures)
						     .setActiveTexture(2)
						     .setTranslation(iconPosX, 0, 0)
						     .setRotation(0, 0, -90)
						     .setScale(sW/4)
						     .setType('aura')
						     .setClickable(false);
	scene.icons.push(sprite);

	// Create the right icon
	sprite  = screen.addSprite()
							  .setTextures(scene.iconsTextures)
						      .setActiveTexture(3)
						      .setTranslation(iconPosX, iconPosY, 0)
						      .setRotation(0, 0, -90)
						      .setScale(sW/6)
						      .setType('aura')
						      .setClickable(false);
	scene.icons.push(sprite);

	// Create the far right icon
	sprite  = screen.addSprite()
							  .setTextures(scene.iconsTextures)
						      .setActiveTexture(4)
						      .setTranslation(iconPosX, 1.7 * iconPosY, 0)
						      .setRotation(0, 0, -90)
						      .setScale(sW/10)
						      .setType('aura')
						      .setClickable(false);
	scene.icons.push(sprite);

	// Create the hotspots
	scene.leftHotspot = screen.addSprite()
							  .setTranslation(iconPosX,  -1.3 * iconPosY, 0)
							  .setScale(sW/3)
							  .setType("sensor")
							  .setColor([1, 0, 0]);
	scene.leftHotspot.onClick = function() { iconsShift('left'); }
	
	scene.rightHotspot = screen.addSprite()
							   .setTranslation(iconPosX,  1.3 * iconPosY, 0)
							   .setScale(sW/3)
							   .setType("sensor")
							   .setColor([0, 1, 0]);
	scene.rightHotspot.onClick = function() { iconsShift('right'); }

	// Cache the current location index
	scene.currentIconIndex = 2;
}

function iconsShift(direction) {
	var iconsCount      = scene.icons.length;
	var locationsCount  = scene.iconsLocations.length;
	var animDuration    = 500;

	// Shift the current iconIndex
	if (direction === 'left') {
		scene.currentIconIndex = modulus(scene.currentIconIndex + 1, locationsCount);
	} else {
		scene.currentIconIndex = modulus(scene.currentIconIndex - 1, locationsCount);
	}

	// Rotate the icons array
	var shiftedIcons = arrayRotate(scene.icons, direction);

	// Animate the icons
	var targetIndex   = 0;
	var textureIndex  = 0;
	for (i = 0; i < iconsCount; i++) {
		var updateTexture = false;
		if (direction === 'left') {
			targetIndex  = modulus (i - 1, iconsCount);
			if (targetIndex == (iconsCount - 1)) {
				textureIndex = modulus(scene.icons[targetIndex].getActiveTexture() + 1, locationsCount);
				scene.icons[i].setActiveTexture(textureIndex);
			}
		} else {
			targetIndex  = modulus (i + 1, iconsCount);
			if (targetIndex == 0) {
				textureIndex = modulus(scene.icons[targetIndex].getActiveTexture() - 1, locationsCount);
				scene.icons[i].setActiveTexture(textureIndex);
			}
		}
		
		var anim = scene.icons[i].animate();
		anim.translate(scene.icons[targetIndex].getTranslation())
			.scale(scene.icons[targetIndex].getScale())
		    .alpha(scene.icons[targetIndex].getAlpha())
		    .duration(animDuration);
		anim.onStart = function() { 
			scene.leftHotspot.setClickable(false);
			scene.rightHotspot.setClickable(false);
		}
		anim.onEnd = function() {
			scene.leftHotspot.setClickable(true);
			scene.rightHotspot.setClickable(true);
		}
	}

	// Update the icons array
	scene.icons = shiftedIcons;
	
	// Pin the new current location
	pinLocation(scene.currentIconIndex);
}

function pinBounce() {
	if (scene.pinLat.getScale()[0] > 1) {
		scene.pinLat.animate().scale(1.00).duration(250).onEnd = function () { pinBounce(); }
	} else {
		scene.pinLat.animate().scale(1.05).duration(250).onEnd = function () { pinBounce(); }
	}
}

function pinLocation(locIndex) {
	var str    = scene.iconsLocations[locIndex].replace(/°/g, "").replace(/,/g, "").split(" ");
	var lat	   = parseFloat(str[0]);
	var lon	   = parseFloat(str[2]);
	var latDir = str[1];
	var lonDir = str[3]; 

	if (latDir == "N") scene.pinLat.animate().rotateX(-lat).duration(500);
	if (latDir == "S") scene.pinLat.animate().rotateX(+lat).duration(500);

	if (lonDir == "E") scene.pinLon.animate().rotateZ(-lon).duration(500);
	if (lonDir == "W") scene.pinLon.animate().rotateZ(+lon).duration(500);

}

function modulus(x, y) {
	return ((x % y) + y) % y;
}

function arrayRotate(array, direction) {
	array = array.slice();
	if (direction === 'left') {
    	array.push(array.shift());
  	} else {
  		array.unshift(array.pop());
  	}
  	return array;
}

